#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p native
build_object=$(mktemp)
trap 'rm -f "$build_object"' EXIT
gcc -c -fPIC -O2 -Wall -Wextra -Werror -o "$build_object" source/scroll_fix.c
g++ -std=c++17 -shared -fPIC -O2 -Wall -Wextra -Werror -o native/scroll_fix.so -x c++ source/map_zoom.cpp -x none "$build_object" -ldl
