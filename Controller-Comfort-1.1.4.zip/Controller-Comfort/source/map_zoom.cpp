// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
// Native map zoom remains OpenMW's own handler. Controller events are timed
// independently of cursor visibility, hover state, and rendering frame rate.
#include <dlfcn.h>
#include <string_view>
#include <vector>
#include <chrono>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include "map_zoom_timing.h"
namespace MyGUI { class Widget; }
struct Coord {int left,top,width,height;};
struct Point {int left,top;};
static void *map_root;
static Coord map_coord{},remembered_map_coord{};
static void *other_pages[3]{};
static bool other_page_visible[3]{},staged_map;
static void stage_map_presentation();
static void finish_map_presentation(bool restore_visibility);
static bool interface_open;
static bool remember_map_page,restore_map_page,controller_seen;
static int restore_trigger_phase;
static int16_t right_y;
static int32_t controller_id;
static ComfortZoomTiming timing;
extern "C" int comfort_enabled(void);
extern "C" void comfort_inject_map_wheel(void*,int,int,int);
template<class T>static T api(const char *name){return reinterpret_cast<T>(dlsym(RTLD_NEXT,name));}
using Widgets=std::vector<MyGUI::Widget*>;
Widgets comfort_layout(void*,std::string_view,std::string_view,MyGUI::Widget*)
 __asm__("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
Widgets comfort_layout(void *self,std::string_view file,std::string_view prefix,MyGUI::Widget *parent){
 static auto original=api<Widgets(*)(void*,std::string_view,std::string_view,MyGUI::Widget*)>("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
 auto widgets=original(self,file,prefix,parent);
 if(file=="openmw_map_window.layout" && !widgets.empty()){map_root=widgets[0];map_coord={};}
 if(!widgets.empty()){
  if(file=="openmw_inventory_window.layout")other_pages[0]=widgets[0];
  if(file=="openmw_spell_window.layout")other_pages[1]=widgets[0];
  if(file=="openmw_stats_window.layout")other_pages[2]=widgets[0];
 }
 return widgets;
}
void comfort_coord(void*,const Coord&) __asm__("_ZN5MyGUI6Window8setCoordERKNS_5types6TCoordIiEE");
void comfort_coord(void *self,const Coord& coord){
 static auto original=api<void(*)(void*,const Coord&)>("_ZN5MyGUI6Window8setCoordERKNS_5types6TCoordIiEE");
 if(self==map_root)map_coord=coord;
 original(self,coord);
}
// Present the remembered map before the first draw. The native controller
// page catches up in the next input pass; its temporary Inventory page must
// never be rendered while that happens.
static void stage_map_presentation(){
 if(staged_map || !controller_seen || !map_root || remembered_map_coord.height<=0)return;
 if(map_coord.height>0 && map_coord.top>=0 && map_coord.top<map_coord.height)return;
 static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 static auto set_visible=api<void(*)(void*,bool)>("_ZN5MyGUI6Widget10setVisibleEb");
 if(!visible || !set_visible || !visible(map_root))return;
 staged_map=true;
 for(int i=0;i<3;i++)if(other_pages[i]){other_page_visible[i]=visible(other_pages[i]);set_visible(other_pages[i],false);}
 comfort_coord(map_root,remembered_map_coord);
 if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fputs("[Comfort Map] Presenting remembered map before first draw\n",stderr);
}
static void finish_map_presentation(bool restore_visibility){
 if(!staged_map)return;
 staged_map=false;
 if(!restore_visibility)return; // Mode closure has already hidden these pages.
 static auto set_visible=api<void(*)(void*,bool)>("_ZN5MyGUI6Widget10setVisibleEb");
 for(int i=0;i<3;i++)if(other_pages[i])set_visible(other_pages[i],other_page_visible[i]);
}
void comfort_caption(void*,const void*) __asm__("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
void comfort_caption(void *self,const void *text){
 static auto original=api<void(*)(void*,const void*)>("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
 if(comfort_enabled()){
  static auto utf=api<const char*(*)(const void*)>("_ZNK5MyGUI7UString12asUTF8_c_strEv");
  const char *s=utf?utf(text):nullptr;
  if(s && std::strncmp(s,"__COMFORT_MAP_UI__:",19)==0){bool next=std::strcmp(s+19,"1")==0;
   if(next && !interface_open)restore_map_page=remember_map_page;
   if(!next){restore_map_page=false;restore_trigger_phase=0;finish_map_presentation(false);}
   interface_open=next;
   if(next && restore_map_page)stage_map_presentation();
   if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fprintf(stderr,"[Comfort Map] Interface mode: %d; remember map: %d\n",interface_open,remember_map_page);}
 }
 original(self,text);
}
static void *map_input(){
 if(!comfort_enabled() || !interface_open || !map_root || map_coord.width<=0 || map_coord.height<=0
    || map_coord.top<0 || map_coord.top>=map_coord.height)return nullptr;
 static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 static auto input=api<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
 static auto modal=api<bool(*)(void*)>("_ZNK5MyGUI12InputManager10isModalAnyEv");
 if(!visible || !input || !modal || !visible(map_root))return nullptr;
 void *manager=input();return manager && !modal(manager)?manager:nullptr;
}
extern "C" int comfort_controller_zoom_delta(void*,int delta){
 // Suppress native per-frame stick zoom while our map timer owns it.
 // Physical mouse wheel bypasses this function in scroll_fix.c.
 return map_input()?0:delta;
}
// Restore OpenMW's page-zero edge case using its existing previous-page
// controller action, only after the menu has fully reopened on another page.
extern "C" int comfort_map_queued_event(void *event){
 if(!restore_trigger_phase || !interface_open)return 0;
 auto b=static_cast<unsigned char*>(event);std::memset(b,0,56);
 uint32_t type=0x650;std::memcpy(b,&type,4);std::memcpy(b+8,&controller_id,4);
 b[12]=4; // SDL_CONTROLLER_AXIS_TRIGGERLEFT
 int16_t value=restore_trigger_phase==1?32767:0;std::memcpy(b+16,&value,2);
 if(++restore_trigger_phase>2){restore_trigger_phase=0;restore_map_page=false;finish_map_presentation(true);}
 return 1;
}
extern "C" void comfort_map_event(void *event){
 auto b=static_cast<unsigned char*>(event);uint32_t type;std::memcpy(&type,b,4);
 if(type==0x650 || type==0x651 || type==0x652){controller_seen=true;std::memcpy(&controller_id,b+8,4);}
 if(type==0x650 && b[12]==3){std::memcpy(&right_y,b+16,2);std::memcpy(&controller_id,b+8,4);}
 if(type==0x654){int32_t id;std::memcpy(&id,b+8,4);if(id==controller_id)right_y=0;}
 if(type==0x200 && b[12]==13)right_y=0; // SDL_WINDOWEVENT_FOCUS_LOST
}
extern "C" void comfort_map_frame(void){
 static auto previous=std::chrono::steady_clock::now();
 auto now=std::chrono::steady_clock::now();double dt=std::chrono::duration<double>(now-previous).count();previous=now;
 void *input=map_input();
 if(interface_open && restore_map_page && !restore_trigger_phase){
  static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
  if((input && !staged_map) || !controller_seen || !map_root || !visible || !visible(map_root)){restore_map_page=false;finish_map_presentation(true);}
  else {
   static auto get_input=api<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
   static auto modal=api<bool(*)(void*)>("_ZNK5MyGUI12InputManager10isModalAnyEv");
   void *manager=get_input?get_input():nullptr;
   if(manager && modal && !modal(manager)){
    restore_trigger_phase=1;
    if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fputs("[Comfort Map] Restoring remembered map page\n",stderr);
   }
  }
 }
 if(interface_open && !restore_map_page && !restore_trigger_phase){
  // Geometry distinguishes the active controller page from offscreen pages.
  // Don't let a modal dialog erase the page behind it.
  static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
  // Closing the interface hides its widgets before Lua reports the mode
  // change. Freeze the last visible page through that intermediate frame.
  if(map_root && visible && visible(map_root))
   remember_map_page=map_coord.height>0 && map_coord.top>=0 && map_coord.top<map_coord.height;
  if(remember_map_page)remembered_map_coord=map_coord;
 }
 int direction=timing.advance(input?right_y:0,dt);
 if(!input || !direction)return;
 // Re-evaluate focus on every step. Switching world/local replaces the
 // event widget beneath the pointer, so stale hover must never gate zoom.
 int x=map_coord.left+map_coord.width/2,y=map_coord.top+map_coord.height/2;
 static auto position=api<const Point&(*)(void*)>("_ZNK5MyGUI12InputManager16getMousePositionEv");
 if(position){auto p=position(input);if(p.left>map_coord.left+16 && p.left<map_coord.left+map_coord.width-16
   && p.top>map_coord.top+40 && p.top<map_coord.top+map_coord.height-40){x=p.left;y=p.top;}}
 if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fprintf(stderr,"[Comfort Map] Zoom %d at %d,%d\n",direction,x,y);
 comfort_inject_map_wheel(input,x,y,direction*120);
}
