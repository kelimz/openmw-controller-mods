/* OpenMW 0.51 compatibility fix: keep MyGUI's wheel total continuous when
 * switching between controller-generated scrolling and SDL mouse motion.
 * Installed only for this OpenMW Flatpak; original SDL/MyGUI calls are retained.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "mod_gate.h"
int comfort_enabled(void) { static int state=-1; if(state<0)state=mod_selected("controller_menu_guard.omwscripts"); return state; }
static _Thread_local uint32_t event_type;
static int wheel_total, native_total, physical_total;
static int announced;
extern int comfort_controller_zoom_delta(void *input, int delta);
extern void comfort_map_event(void *event);
extern void comfort_map_frame(void);
extern int comfort_map_queued_event(void *event);
int SDL_PollEvent(void *event) {
    static int (*original)(void *);
    if (!original) original = dlsym(RTLD_NEXT, "SDL_PollEvent");
    if (!original) abort();
    int result = comfort_enabled() && event && comfort_map_queued_event(event);
    if (!result) result = original(event);
    event_type = result && event ? *(uint32_t *)event : 0;
    if (comfort_enabled()) {
        if (result && event) comfort_map_event(event);
        else if (!result) comfort_map_frame();
    }
    return result;
}
typedef unsigned char cpp_bool;
cpp_bool fixed_move(void *self, int x, int y, int raw)
    __asm__("_ZN5MyGUI12InputManager15injectMouseMoveEiii");
cpp_bool fixed_move(void *self, int x, int y, int raw) {
    static cpp_bool (*original)(void *, int, int, int);
    if (!original) original = dlsym(RTLD_NEXT, "_ZN5MyGUI12InputManager15injectMouseMoveEiii");
    if (!original) abort();
    if (!comfort_enabled()) return original(self, x, y, raw);
    if (!announced) {
        fputs("[Controller Scroll Fix] continuous wheel tracking enabled\n", stderr);
        announced = 1;
    }
    if (event_type == 0x400) { /* SDL_MOUSEMOTION carries SDL's older wheel total. */
        physical_total = raw;
        native_total = raw;
    } else if (event_type == 0x403) { /* SDL_MOUSEWHEEL */
        wheel_total += raw - physical_total;
        physical_total = raw;
        native_total = raw;
    } else { /* OpenMW's synthetic controller movement. */
        wheel_total += comfort_controller_zoom_delta(self, raw - native_total);
        native_total = raw;
    }
    return original(self, x, y, wheel_total);
}


/* Timer-driven map input shares the corrected wheel total. It bypasses only
 * this wrapper, leaving MyGUI's normal map handlers responsible for zoom. */
void comfort_inject_map_wheel(void *input, int x, int y, int delta) {
    typedef cpp_bool (*Move)(void *, int, int, int);
    static Move original;
    if (!original) original = dlsym(RTLD_NEXT, "_ZN5MyGUI12InputManager15injectMouseMoveEiii");
    if (original) {
        /* MyGUI returns early for wheel changes, before hit-testing. A
         * zero-wheel motion is required to focus the newly active map layer. */
        original(input, x, y, wheel_total);
        wheel_total += delta;
        original(input, x, y, wheel_total);
    }
}
