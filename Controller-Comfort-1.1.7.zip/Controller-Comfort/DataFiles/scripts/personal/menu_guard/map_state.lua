-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (c) 2026 kelimz; predominantly AI-generated.
local ui=require('openmw.ui')
local util=require('openmw.util')
local I=require('openmw.interfaces')
local bridge
local function refresh()
 local active=I.UI.getMode()==I.UI.MODE.Interface
 if bridge then bridge:destroy() end
 bridge=ui.create{type=ui.TYPE.Text,layer='HUD',name='ComfortMapMode',props={
  visible=false,position=util.vector2(-10000,-10000),size=util.vector2(1,1),
  text='__COMFORT_MAP_UI__:'..(active and '1' or '0')}}
end
return {engineHandlers={onInit=refresh,onLoad=refresh},eventHandlers={UiModeChanged=refresh}}
