// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
// Keep repeated pointer clicks on barter price +/- in the normal mouse path.
#include <dlfcn.h>
#include <string>
#include <string_view>
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
static void *trade_root,*increase_button,*decrease_button;
static bool mapped_press;
static int32_t mapped_controller;
template<class T>static T barter_api(const char *name){return reinterpret_cast<T>(dlsym(RTLD_NEXT,name));}
extern "C" void comfort_barter_layout(void *root,const char *prefix,size_t length){
 static auto find=barter_api<void*(*)(void*,std::string_view)>("_ZN5MyGUI6Widget10findWidgetESt17basic_string_viewIcSt11char_traitsIcEE");
 trade_root=root;std::string base(prefix,length);
 increase_button=find(root,base+"IncreaseButton");decrease_button=find(root,base+"DecreaseButton");mapped_press=false;
}
extern "C" void comfort_barter_event(void *event){
 auto b=static_cast<unsigned char*>(event);uint32_t type;std::memcpy(&type,b,4);
 if((type!=0x651 && type!=0x652)||b[12]!=0)return; // Controller A only.
 int32_t controller;std::memcpy(&controller,b+8,4);
 const bool down=type==0x651;
 if(!down){if(!mapped_press || controller!=mapped_controller)return;}
 else {
  if(!trade_root)return;
  static auto visible=barter_api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
  static auto input=barter_api<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
  static auto focus=barter_api<void*(*)(void*)>("_ZNK5MyGUI12InputManager19getMouseFocusWidgetEv");
  static auto parent=barter_api<void*(*)(void*)>("_ZNK5MyGUI6Widget9getParentEv");
  static auto modal=barter_api<bool(*)(void*)>("_ZNK5MyGUI12InputManager10isModalAnyEv");
  if(!visible || !input || !focus || !parent || !modal || !visible(trade_root))return;
  void *manager=input();if(!manager || modal(manager))return;
  bool price_button=false;
  for(void *w=focus(manager);w;w=parent(w))if(w==increase_button || w==decrease_button){price_button=true;break;}
  if(!price_button)return;
  mapped_press=true;mapped_controller=controller;
 }
 uint32_t timestamp;std::memcpy(&timestamp,b+4,4);std::memset(b,0,56);
 type=down?0x401:0x402;std::memcpy(b,&type,4);std::memcpy(b+4,&timestamp,4);
 b[16]=1;b[17]=down?1:0;b[18]=1; // SDL left button, state, one click.
 static auto mouse=barter_api<uint32_t(*)(int*,int*)>("SDL_GetMouseState");
 int x=0,y=0;if(mouse)mouse(&x,&y);std::memcpy(b+20,&x,4);std::memcpy(b+24,&y,4);
 if(!down)mapped_press=false;
 if(std::getenv("OPENMW_COMFORT_BARTER_DEBUG"))std::fprintf(stderr,"[Barter Cursor] Pointer click %s\n",down?"down":"up");
}
