// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
#include <dlfcn.h>
#include <string>
#include <string_view>
#include <unordered_map>
#include <cstdio>
#include <cstdlib>
#include "dialogue_scroll.h"
struct TopicCoord{int left,top,width,height;};
struct TopicSize{int width,height;};
struct TopicPoint{int left,top;};
struct TopicAlign{unsigned value;};
static void *topic_scroll,*selected_topic;
static std::string topic_prefix;
static std::unordered_map<void*,TopicCoord> topic_rows;
static bool pending_selection;
extern "C" int comfort_enabled(void);
template<class T>static T topic_api(const char*n){return reinterpret_cast<T>(dlsym(RTLD_NEXT,n));}
extern "C" void comfort_dialogue_layout(void *root,const char *prefix,size_t length){
 static auto find=topic_api<void*(*)(void*,std::string_view)>("_ZN5MyGUI6Widget10findWidgetESt17basic_string_viewIcSt11char_traitsIcEE");
 std::string base(prefix,length);base+="TopicsList";
 topic_scroll=find(root,base+"_ScrollView");topic_prefix=base+"_item_";
 topic_rows.clear();selected_topic=nullptr;pending_selection=false;
}
void *topic_create(void*,std::string_view,std::string_view,const TopicCoord&,TopicAlign,std::string_view)
 __asm__("_ZN5MyGUI6Widget13createWidgetTESt17basic_string_viewIcSt11char_traitsIcEES4_RKNS_5types6TCoordIiEENS_5AlignES4_");
void *topic_create(void*self,std::string_view type,std::string_view skin,const TopicCoord&c,TopicAlign align,std::string_view name){
 static auto original=topic_api<void*(*)(void*,std::string_view,std::string_view,const TopicCoord&,TopicAlign,std::string_view)>("_ZN5MyGUI6Widget13createWidgetTESt17basic_string_viewIcSt11char_traitsIcEES4_RKNS_5types6TCoordIiEENS_5AlignES4_");
 void *widget=original(self,type,skin,c,align,name);
 if(!topic_prefix.empty() && name.substr(0,topic_prefix.size())==topic_prefix)topic_rows[widget]=c;
 return widget;
}
void topic_size(void*,const TopicSize&) __asm__("_ZN5MyGUI6Widget7setSizeERKNS_5types5TSizeIiEE");
void topic_size(void*self,const TopicSize&size){
 static auto original=topic_api<void(*)(void*,const TopicSize&)>("_ZN5MyGUI6Widget7setSizeERKNS_5types5TSizeIiEE");original(self,size);
 auto row=topic_rows.find(self);if(row!=topic_rows.end()){row->second.width=size.width;row->second.height=size.height;}
}
void topic_selected(void*,bool) __asm__("_ZN5MyGUI6Button16setStateSelectedEb");
void topic_selected(void*self,bool selected){
 static auto original=topic_api<void(*)(void*,bool)>("_ZN5MyGUI6Button16setStateSelectedEb");original(self,selected);
 if(!comfort_enabled())return;
 if(selected && topic_rows.count(self)){selected_topic=self;pending_selection=true;}
 else if(!selected && selected_topic==self){selected_topic=nullptr;pending_selection=false;}
}
void topic_destroy(void*,void*) __asm__("_ZN5MyGUI3Gui13destroyWidgetEPNS_6WidgetE");
void topic_destroy(void*self,void*widget){
 static auto original=topic_api<void(*)(void*,void*)>("_ZN5MyGUI3Gui13destroyWidgetEPNS_6WidgetE");
 topic_rows.erase(widget);if(selected_topic==widget){selected_topic=nullptr;pending_selection=false;}
 original(self,widget);
}
void topic_offset(void*,const TopicPoint&) __asm__("_ZN5MyGUI10ScrollView13setViewOffsetERKNS_5types6TPointIiEE");
void topic_offset(void*self,const TopicPoint&proposed){
 static auto original=topic_api<void(*)(void*,const TopicPoint&)>("_ZN5MyGUI10ScrollView13setViewOffsetERKNS_5types6TPointIiEE");
 auto row=topic_rows.find(selected_topic);TopicPoint adjusted=proposed;
 bool fix=comfort_enabled() && self==topic_scroll && pending_selection && row!=topic_rows.end();
 TopicSize view{};
 if(fix){
  pending_selection=false;
  static auto view_size=topic_api<TopicSize(*)(void*)>("_ZNK5MyGUI10ScrollView11getViewSizeEv");
  static auto canvas_size=topic_api<TopicSize(*)(void*)>("_ZNK5MyGUI10ScrollView13getCanvasSizeEv");
  view=view_size(self);adjusted.top=comfort_topic_offset(proposed.top,row->second.top,row->second.height,view.height,canvas_size(self).height);
 }
 original(self,adjusted);
 if(fix && std::getenv("OPENMW_COMFORT_DIALOGUE_DEBUG")){
  static auto offset=topic_api<TopicPoint(*)(void*)>("_ZNK5MyGUI10ScrollView13getViewOffsetEv");
  auto actual=offset(self);auto c=row->second;
  std::fprintf(stderr,"[Dialogue Topic Scroll] row=%d height=%d view=%d proposed=%d actual=%d visible=%d..%d\n",c.top,c.height,view.height,proposed.top,actual.top,c.top+actual.top,c.top+c.height+actual.top);
 }
}
