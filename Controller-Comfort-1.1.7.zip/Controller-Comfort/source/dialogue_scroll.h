// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
#ifndef COMFORT_DIALOGUE_SCROLL_H
#define COMFORT_DIALOGUE_SCROLL_H
#include <algorithm>
inline int comfort_topic_offset(int proposed,int top,int height,int viewport,int canvas){
 if(viewport<=0 || height<=0)return proposed;
 const int margin=std::min(8,viewport/4);
 int offset=proposed;
 if(height>viewport-2*margin || top+offset<margin)offset=margin-top;
 else if(top+height+offset>viewport-margin)offset=viewport-margin-top-height;
 return std::clamp(offset,std::min(0,viewport-canvas),0);
}
#endif
