// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
// Native map zoom remains OpenMW's own handler. Controller events are timed
// independently of cursor visibility, hover state, and rendering frame rate.
#include <dlfcn.h>
#include <string_view>
#include <vector>
#include <chrono>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include "map_zoom_timing.h"
namespace MyGUI { class Widget; }
struct Coord {int left,top,width,height;};
struct Point {int left,top;};
static void *map_root;
static Coord map_coord{};
static void *other_pages[3]{},*inventory_tabs;
static bool interface_open,remember_map_page,reopen_filter_logged;
static int16_t right_y;
static int32_t controller_id;
static ComfortZoomTiming timing;
extern "C" int comfort_enabled(void);
extern "C" void comfort_inject_map_wheel(void*,int,int,int);
template<class T>static T api(const char *name){return reinterpret_cast<T>(dlsym(RTLD_NEXT,name));}
extern "C" void comfort_dialogue_layout(void*,const char*,size_t);
extern "C" void comfort_barter_layout(void*,const char*,size_t);
using Widgets=std::vector<MyGUI::Widget*>;
Widgets comfort_layout(void*,std::string_view,std::string_view,MyGUI::Widget*)
 __asm__("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
Widgets comfort_layout(void *self,std::string_view file,std::string_view prefix,MyGUI::Widget *parent){
 static auto original=api<Widgets(*)(void*,std::string_view,std::string_view,MyGUI::Widget*)>("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
 auto widgets=original(self,file,prefix,parent);
 if(file=="openmw_trade_window.layout" && !widgets.empty())comfort_barter_layout(widgets[0],prefix.data(),prefix.size());
 if(file=="openmw_dialogue_window.layout" && !widgets.empty())comfort_dialogue_layout(widgets[0],prefix.data(),prefix.size());
 if(file=="openmw_map_window.layout" && !widgets.empty()){map_root=widgets[0];map_coord={};}
 if(!widgets.empty()){
  if(file=="openmw_inventory_tabs.layout")inventory_tabs=widgets[0];
  if(file=="openmw_inventory_window.layout")other_pages[0]=widgets[0];
  if(file=="openmw_spell_window.layout")other_pages[1]=widgets[0];
  if(file=="openmw_stats_window.layout")other_pages[2]=widgets[0];
 }
 return widgets;
}
void comfort_coord(void*,const Coord&) __asm__("_ZN5MyGUI6Window8setCoordERKNS_5types6TCoordIiEE");
void comfort_coord(void *self,const Coord& coord){
 static auto original=api<void(*)(void*,const Coord&)>("_ZN5MyGUI6Window8setCoordERKNS_5types6TCoordIiEE");
 if(self==map_root)map_coord=coord;
 original(self,coord);
}
// OpenMW's page-zero reopen path advances to the next visible page. During
// that native selection pass only, keep the other pages out of consideration.
// The native page index stays Map from the outset: no delayed trigger, hidden
// window, forced layout, or presentation swap is needed.
bool comfort_visible(void*) __asm__("_ZNK5MyGUI6Widget10getVisibleEv");
bool comfort_visible(void *self){
 static auto original=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 const bool visible=original(self);
 if(visible && comfort_enabled() && remember_map_page && !interface_open
    && map_root && inventory_tabs && original(map_root) && original(inventory_tabs)){
  for(void *page:other_pages)if(self==page){
   if(!reopen_filter_logged && std::getenv("OPENMW_COMFORT_MAP_DEBUG")){
    std::fputs("[Comfort Map] Keeping native Map page during reopen\n",stderr);reopen_filter_logged=true;
   }
   return false;
  }
 }
 return visible;
}
void comfort_caption(void*,const void*) __asm__("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
void comfort_caption(void *self,const void *text){
 static auto original=api<void(*)(void*,const void*)>("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
 if(comfort_enabled()){
  static auto utf=api<const char*(*)(const void*)>("_ZNK5MyGUI7UString12asUTF8_c_strEv");
  const char *s=utf?utf(text):nullptr;
  if(s && std::strncmp(s,"__COMFORT_MAP_UI__:",19)==0){bool next=std::strcmp(s+19,"1")==0;
   interface_open=next;
   if(!next)reopen_filter_logged=false;
   if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fprintf(stderr,"[Comfort Map] Interface mode: %d; remember map: %d\n",interface_open,remember_map_page);}
 }
 original(self,text);
}
static void *map_input(){
 if(!comfort_enabled() || !interface_open || !map_root || map_coord.width<=0 || map_coord.height<=0
    || map_coord.top<0 || map_coord.top>=map_coord.height)return nullptr;
 static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 static auto input=api<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
 static auto modal=api<bool(*)(void*)>("_ZNK5MyGUI12InputManager10isModalAnyEv");
 if(!visible || !input || !modal || !visible(map_root))return nullptr;
 void *manager=input();return manager && !modal(manager)?manager:nullptr;
}
extern "C" int comfort_controller_zoom_delta(void*,int delta){
 // Suppress native per-frame stick zoom while our map timer owns it.
 // Physical mouse wheel bypasses this function in scroll_fix.c.
 return map_input()?0:delta;
}
extern "C" void comfort_map_event(void *event){
 auto b=static_cast<unsigned char*>(event);uint32_t type;std::memcpy(&type,b,4);
 if(type==0x650 || type==0x651 || type==0x652){std::memcpy(&controller_id,b+8,4);}
 if(type==0x650 && b[12]==3){std::memcpy(&right_y,b+16,2);std::memcpy(&controller_id,b+8,4);}
 if(type==0x654){int32_t id;std::memcpy(&id,b+8,4);if(id==controller_id)right_y=0;}
 if(type==0x200 && b[12]==13)right_y=0; // SDL_WINDOWEVENT_FOCUS_LOST
}
extern "C" void comfort_map_frame(void){
 static auto previous=std::chrono::steady_clock::now();
 auto now=std::chrono::steady_clock::now();double dt=std::chrono::duration<double>(now-previous).count();previous=now;
 void *input=map_input();
 if(interface_open){
  static auto visible=api<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
  // Preserve the last page while native widgets are closing, before the Lua
  // mode notification is delivered. Other active pages leave Map offscreen.
  if(map_root && visible && visible(map_root))
   remember_map_page=map_coord.height>0 && map_coord.top>=0 && map_coord.top<map_coord.height;
 }
 int direction=timing.advance(input?right_y:0,dt);
 if(!input || !direction)return;
 // Re-evaluate focus on every step. Switching world/local replaces the
 // event widget beneath the pointer, so stale hover must never gate zoom.
 int x=map_coord.left+map_coord.width/2,y=map_coord.top+map_coord.height/2;
 static auto position=api<const Point&(*)(void*)>("_ZNK5MyGUI12InputManager16getMousePositionEv");
 if(position){auto p=position(input);if(p.left>map_coord.left+16 && p.left<map_coord.left+map_coord.width-16
   && p.top>map_coord.top+40 && p.top<map_coord.top+map_coord.height-40){x=p.left;y=p.top;}}
 if(std::getenv("OPENMW_COMFORT_MAP_DEBUG"))std::fprintf(stderr,"[Comfort Map] Zoom %d at %d,%d\n",direction,x,y);
 comfort_inject_map_wheel(input,x,y,direction*120);
}
