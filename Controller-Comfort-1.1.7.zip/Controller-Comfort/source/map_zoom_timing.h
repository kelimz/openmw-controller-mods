// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
#ifndef COMFORT_MAP_ZOOM_TIMING_H
#define COMFORT_MAP_ZOOM_TIMING_H
#include <algorithm>
#include <cmath>
struct ComfortZoomTiming {
 double phase=0;
 int direction=0;
 int advance(int axis,double seconds){
  const double strength=std::abs(axis/32768.0);
  if(strength<=0.22){phase=0;direction=0;return 0;}
  const int next=axis<0?1:-1;
  if(next!=direction){direction=next;phase=0;return next;}
  const double travel=std::clamp((strength-0.22)/0.78,0.0,1.0);
  // 1.5 to 8 native steps/sec, with fine control near the deadzone.
  const double rate=1.5+6.5*travel*travel;
  // Never burst queued wheel events after a loading/rendering stall.
  phase+=std::clamp(seconds,0.0,0.05)*rate;
  if(phase<1)return 0;
  phase-=1;return direction;
 }
};
#endif
