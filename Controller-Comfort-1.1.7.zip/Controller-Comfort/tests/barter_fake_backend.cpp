// SPDX-License-Identifier: GPL-3.0-only
// Predominantly AI-generated.
#include <string_view>
#include <cstdint>
extern "C" {int hovered=1,visible_flag=1,modal_flag=0;}
void *find(void*,std::string_view) __asm__("_ZN5MyGUI6Widget10findWidgetESt17basic_string_viewIcSt11char_traitsIcEE");
void *find(void*,std::string_view n){return reinterpret_cast<void*>(n.find("IncreaseButton")!=n.npos?1:2);}
bool visible(void*) __asm__("_ZNK5MyGUI6Widget10getVisibleEv");bool visible(void*){return visible_flag;}
void *input() __asm__("_ZN5MyGUI12InputManager14getInstancePtrEv");void *input(){return reinterpret_cast<void*>(4);}
void *focus(void*) __asm__("_ZNK5MyGUI12InputManager19getMouseFocusWidgetEv");void *focus(void*){return reinterpret_cast<void*>(uintptr_t(hovered));}
void *parent(void*) __asm__("_ZNK5MyGUI6Widget9getParentEv");void *parent(void*w){return reinterpret_cast<void*>(w==reinterpret_cast<void*>(20)?1:0);}
bool modal(void*) __asm__("_ZNK5MyGUI12InputManager10isModalAnyEv");bool modal(void*){return modal_flag;}
extern "C" uint32_t SDL_GetMouseState(int*x,int*y){*x=77;*y=88;return 0;}
