static int previous,focused;
int delivered;
unsigned char move(void*,int,int,int) __asm__("_ZN5MyGUI12InputManager15injectMouseMoveEiii");
unsigned char move(void *self,int x,int y,int z){
 (void)self;(void)x;(void)y;
 int delta=z-previous;previous=z;
 /* Match MyGUI: a wheel change returns before pointer hit testing. */
 if(delta){if(focused)delivered++;focused=0;return 1;}
 focused=1;return 1;
}
