// SPDX-License-Identifier: GPL-3.0-only
// Predominantly AI-generated.
#include <initializer_list>
#include <cstdint>
#include <cstring>
#include <cassert>
#include <cstdio>
extern "C" {void comfort_barter_layout(void*,const char*,size_t);void comfort_barter_event(void*);extern int hovered,visible_flag,modal_flag;}
struct Event{unsigned char b[56];};
Event event(bool down,int button=0,int id=7){Event e{};uint32_t t=down?0x651:0x652;std::memcpy(e.b,&t,4);std::memcpy(e.b+8,&id,4);e.b[12]=button;return e;}
uint32_t type(const Event&e){uint32_t t;std::memcpy(&t,e.b,4);return t;}
void unchanged(Event e){Event before=e;comfort_barter_event(e.b);assert(!std::memcmp(e.b,before.b,56));}
int main(){
 unchanged(event(true));comfort_barter_layout(reinterpret_cast<void*>(3),"trade_",6);
 for(int button:{1,2}){hovered=button;for(int i=0;i<5;i++){auto d=event(true),u=event(false);comfort_barter_event(d.b);comfort_barter_event(u.b);assert(type(d)==0x401&&type(u)==0x402);assert(d.b[16]==1&&d.b[17]==1&&u.b[17]==0);}}
 hovered=9;unchanged(event(true));hovered=1;unchanged(event(true,1));modal_flag=1;unchanged(event(true));modal_flag=0;visible_flag=0;unchanged(event(true));visible_flag=1;
 hovered=20;auto d=event(true);comfort_barter_event(d.b);assert(type(d)==0x401);hovered=9;visible_flag=0;auto u=event(false);comfort_barter_event(u.b);assert(type(u)==0x402);
 puts("PASS: repeated +/- clicks without motion, child-widget targeting, balanced release after focus changes, and unchanged input elsewhere.");
}
