#include "../source/dialogue_scroll.h"
#include <cassert>
#include <cstdio>
void check(int proposed,int top,int h,int view,int canvas){int y=comfort_topic_offset(proposed,top,h,view,canvas);assert(y<=0&&y>=std::min(0,view-canvas));assert(top+y>=0);assert(top+h+y<=view);}
int main(){
 check(0,3,24,150,1000);check(0,160,64,150,1000);check(-100,210,28,150,1000);
 check(-200,40,52,150,1000);check(-800,930,64,150,1000);check(0,30,24,150,100);
 int n=0;for(int view:{90,140,240,328})for(int h:{20,42,64})for(int top=3;top<1300;top+=h+6){check(-(top/4),top,h,view,1400);++n;}
 assert(comfort_topic_offset(-140,200,100,90,1400)==-192);
 printf("PASS: %d geometry combinations plus top/bottom/wrapped-row checks; selected text stays within viewport.\n",n+6);
}
