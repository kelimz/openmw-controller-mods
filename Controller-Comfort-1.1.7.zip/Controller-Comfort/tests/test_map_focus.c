#include <assert.h>
#include <stdio.h>
extern int delivered;
extern void comfort_inject_map_wheel(void*,int,int,int);
int main(void){
 /* No prior mouse movement; each step changes map layer/invalidates focus. */
 comfort_inject_map_wheel(0,400,300,120);assert(delivered==1);
 comfort_inject_map_wheel(0,400,300,120);assert(delivered==2);
 comfort_inject_map_wheel(0,400,300,-120);assert(delivered==3);
 puts("PASS: no cursor prerequisite; map focus is refreshed across both zoom directions and layer changes.");
}
