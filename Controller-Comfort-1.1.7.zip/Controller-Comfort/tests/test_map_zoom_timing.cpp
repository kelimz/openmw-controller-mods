#include "../source/map_zoom_timing.h"
#include <cassert>
#include <cstdio>
int count(int fps,int axis){ComfortZoomTiming z;int n=0;for(int f=0;f<fps*5;f++)if(z.advance(axis,1.0/fps))++n;return n;}
int main(){
 int low=count(30,-32768),medium=count(60,-32768),high=count(144,-32768);
 assert(std::abs(low-medium)<=1 && std::abs(high-medium)<=1);
 assert(medium>=39 && medium<=41);assert(count(60,-12000)<medium/2);
 ComfortZoomTiming z;assert(z.advance(5000,.016)==0);assert(z.advance(-32768,.016)==1);
 assert(z.advance(32767,.016)==-1);assert(z.advance(0,.016)==0);
 assert(z.advance(-32768,.016)==1);assert(z.advance(-32768,20)==0);
 printf("PASS: 30/60/144 FPS: %d/%d/%d steps in five seconds; slow partial stick, deadzone, instant reversal/restart, no stall bursts.\n",low,medium,high);
}
