-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (c) 2026 kelimz; predominantly AI-generated.
local I = require('openmw.interfaces')
local types = require('openmw.types')
local guardedActor = nil
local active = false
local armed = false
local function state(data)
    guardedActor = data.actor
    active = data.active == true
    armed = data.armed == true
end
local function guard(item, actor)
    if active and not armed and actor == guardedActor then
        actor:sendEvent('PersonalMenuGuardBlocked', {})
        return false
    end
end
for _, t in ipairs({types.Potion, types.Ingredient, types.Armor, types.Clothing,
        types.Weapon, types.Book, types.Light, types.Miscellaneous,
        types.Lockpick, types.Probe, types.Repair}) do
    I.ItemUsage.addHandlerForType(t, guard)
end
print('[Controller Menu Guard] Inventory use guard loaded')
return {eventHandlers = {PersonalMenuGuardState = state}}
