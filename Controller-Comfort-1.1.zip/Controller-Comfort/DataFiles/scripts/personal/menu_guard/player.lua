-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (c) 2026 kelimz; predominantly AI-generated.
local core = require('openmw.core')
local input = require('openmw.input')
local ui = require('openmw.ui')
local I = require('openmw.interfaces')
local self = require('openmw.self')
local active = false
local armed = false
local hinted = false
local function publish()
    core.sendGlobalEvent('PersonalMenuGuardState', {actor = self, active = active, armed = armed})
end
local function updateMode()
    local now = I.UI.getMode() == I.UI.MODE.Interface
    if now ~= active then
        active = now
        armed = false
        hinted = false
        publish()
    end
end
local function controllerButton(button)
    updateMode()
    local b = input.CONTROLLER_BUTTON
    if active and (button == b.DPadUp or button == b.DPadDown or button == b.DPadLeft or button == b.DPadRight) then
        armed = true
        publish()
    end
end
local function mouseButton(button)
    updateMode()
    if active and button == 1 then
        armed = true
        publish()
    end
end
print('[Controller Menu Guard] Player handlers loaded')
return {
    engineHandlers = {
        onControllerButtonPress = controllerButton,
        onMouseButtonPress = mouseButton,
        onLoad = function() active = false; armed = false; publish() end,
    },
    eventHandlers = {
        UiModeChanged = updateMode,
        PersonalMenuGuardBlocked = function()
            if not hinted then
                ui.showMessage('Press the D-pad to select an item before using it.')
                hinted = true
            end
        end,
    },
}
