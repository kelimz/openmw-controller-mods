# Controller Comfort 1.1

Enable or disable **controller_menu_guard.omwscripts** in the OpenMW launcher's
Data Files list, then launch the game normally. Both the scroll fix and inventory
safety guard follow this checkbox. The original filename is retained so existing
saves do not report a missing dependency. No separate toggle program is needed.

The scroll fix prevents stick scrolling and map zoom from being reversed by
cursor movement. Inventory item use requires a D-pad press after opening the
inventory; intentional physical mouse clicks are allowed normally.

Map input bindings remain those configured in OpenMW; this mod repairs scroll rollback and does not provide its own map-pan bindings.

All mod files are in this folder. The installed native bootstrap remains listed
in the OpenMW Flatpak environment but is a pass-through when the checkbox is
off. It does not alter original Morrowind files or controller bindings. Other
mods and the usual Steam shortcut remain in place.

Tested on OpenMW 0.51.0 / MyGUI 3.4.4, Linux x86-64. Source is in source/.
Compile: gcc -shared -fPIC -O2 -Wall -Wextra -Werror -o native/scroll_fix.so source/scroll_fix.c -ldl


## AI-generated and experimental

The implementation, documentation and release packaging were generated with AI assistance through OpenAI Codex, at the author’s direction. Most code is AI-generated. Human-directed testing covers only the scenarios described here; this is not an independently audited or broadly validated release. Bugs, crashes and incompatibilities remain possible. Back up saves and configuration before trying it. No game assets or save files are distributed.

Copyright (c) 2026 kelimz. This project is licensed under GPL-3.0-only; see LICENSE. Distributed WITHOUT ANY WARRANTY. This is an unofficial project and is not endorsed by OpenMW, Bethesda, or Nexus Mods.

## Installation (Linux Flatpak only)

Tested with OpenMW 0.51.0 revision f4bec41444, MyGUI 3.4.4, Linux x86-64. Windows, macOS, other engine versions and other distributions have not been validated. These are native LD_PRELOAD extensions plus Lua scripts, not ordinary portable Lua-only mods. Missing native symbols can terminate startup.

1. Close OpenMW and its launcher. Extract this entire folder to a permanent location under your home directory, such as `~/.local/share/openmw-mods/`.
2. Back up `~/.var/app/org.openmw.OpenMW/config/openmw/openmw.cfg` and your existing Flatpak overrides.
3. Add the absolute path to this mod’s `DataFiles` directory to OpenMW’s data directories (`data="/absolute/path/to/Controller-Comfort/DataFiles"` in that configuration). Enable `controller_menu_guard.omwscripts` in the launcher’s Data Files tab.
4. Inspect the existing override with `flatpak override --user --show org.openmw.OpenMW`. Set LD_PRELOAD to the absolute path of `native/scroll_fix.so` using `flatpak override --user --env=LD_PRELOAD=/absolute/path/to/Controller-Comfort/native/scroll_fix.so org.openmw.OpenMW`. If LD_PRELOAD already contains other helpers, preserve them and append this path separated by a colon. Setting the variable replaces the whole value. When installing both mods, include both paths in one colon-separated value.
5. Launch normally. There is no separate toggle application. Disable `controller_menu_guard.omwscripts` in Data Files and restart OpenMW to disable the mod. To uninstall, remove this helper’s entry from LD_PRELOAD while preserving all other entries, remove its content/data entries, then remove its folder. If startup fails, remove its LD_PRELOAD entry first.

Paths must remain readable inside the Flatpak sandbox. Keep content filenames unchanged for existing saves. Disabling a content file can cause an OpenMW missing-content warning when loading a save that references it.
