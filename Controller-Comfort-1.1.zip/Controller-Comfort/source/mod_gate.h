// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
#ifndef PERSONAL_MOD_GATE_H
#define PERSONAL_MOD_GATE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* OpenMW's Data Files checkbox writes the active content list here. */
static int mod_selected(const char *name) {
    char path[4096],line[8192];
    const char *xdg=getenv("XDG_CONFIG_HOME"),*home=getenv("HOME");
    if(xdg && *xdg) snprintf(path,sizeof(path),"%s/openmw/openmw.cfg",xdg);
    else if(home) snprintf(path,sizeof(path),"%s/.config/openmw/openmw.cfg",home);
    else return 0;
    FILE *f=fopen(path,"r");if(!f)return 0;
    int found=0;
    while(fgets(line,sizeof(line),f)) {
        char *p=line;while(*p==' '||*p=='\t')++p;
        if(strncmp(p,"content",7))continue;
        p+=7;
        while(*p==' '||*p=='\t')++p;
        if(*p++!='=')continue;
        while(*p==' '||*p=='\t')++p;
        size_t n=strcspn(p,"\r\n");p[n]=0;
        while(n && (p[n-1]==' '||p[n-1]=='\t'))p[--n]=0;
        if(n>=2 && p[0]=='"' && p[n-1]=='"'){p[n-1]=0;++p;}
        if(!strcmp(p,name)){found=1;break;}
    }
    fclose(f);return found;
}
#endif
