#include <stdint.h>
uint32_t next_event;
int received_z;
int SDL_PollEvent(void *p) { if (!next_event) return 0; *(uint32_t *)p=next_event; next_event=0; return 1; }
unsigned char fake_move(void *s,int x,int y,int z) __asm__("_ZN5MyGUI12InputManager15injectMouseMoveEiii");
unsigned char fake_move(void *s,int x,int y,int z) { received_z=z;return 1; }
