local base=assert(arg[1], 'Pass package root')..'/DataFiles/scripts/personal/menu_guard/'
local mode=nil
local sent={}
local handlers={}
local messages={}
local actor={sendEvent=function(_,name) messages[#messages+1]=name end}
local b={DPadUp=11,DPadDown=12,DPadLeft=13,DPadRight=14,A=0,B=1}
local I={UI={getMode=function()return mode end,MODE={Interface='Interface'}},ItemUsage={addHandlerForType=function(t,h) handlers[t]=h end}}
local types={}
for _,n in ipairs({'Potion','Ingredient','Armor','Clothing','Weapon','Book','Light','Miscellaneous','Lockpick','Probe','Repair'})do types[n]=n end
package.preload['openmw.interfaces']=function()return I end
package.preload['openmw.types']=function()return types end
local global=assert(loadfile(base..'global.lua'))()
package.preload['openmw.core']=function()return {sendGlobalEvent=function(name,data) sent[#sent+1]=name;global.eventHandlers[name](data) end} end
package.preload['openmw.input']=function()return {CONTROLLER_BUTTON=b} end
package.preload['openmw.self']=function()return actor end
package.preload['openmw.ui']=function()return {showMessage=function(s) messages[#messages+1]=s end} end
local player=assert(loadfile(base..'player.lua'))()
local function change(m)mode=m;player.eventHandlers.UiModeChanged()end
local function use(who)return handlers.Potion({},who or actor)end
assert(use()==nil,'gameplay use should be allowed')
change('Interface')
assert(use()==false,'opening inventory must block use')
player.engineHandlers.onControllerButtonPress(b.A)
assert(use()==false,'pressing A must not unlock use')
assert(use({})==nil,'must not block other actors')
player.engineHandlers.onControllerButtonPress(b.DPadDown)
assert(use()==nil,'D-pad selection must unlock use')
change(nil);change('Interface')
assert(use()==false,'reopening inventory must relock')
player.engineHandlers.onMouseButtonPress(1)
assert(use()==nil,'intentional physical mouse use must work')
change(nil);change('Interface');change('Dialogue')
assert(use()==nil,'other menus must not be blocked')
print('PASS: 8 inventory guard scenarios; all 11 item types registered.')
