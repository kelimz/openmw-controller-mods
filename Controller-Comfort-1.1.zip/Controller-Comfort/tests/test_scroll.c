#include <stdint.h>
#include <assert.h>
#include <stdio.h>
extern uint32_t next_event;
extern int received_z;
int SDL_PollEvent(void *);
unsigned char move(void *,int,int,int) __asm__("_ZN5MyGUI12InputManager15injectMouseMoveEiii");
void check(uint32_t type,int raw,int expected) { uint32_t event=0; next_event=type;SDL_PollEvent(&event);move(0,100,100,raw);assert(received_z==expected); }
int main(void) {
 check(0x400,0,0);
 check(0,-120,-120);
 check(0,-240,-240);
 check(0x400,0,-240); /* Real cursor motion must not undo stick scroll. */
 check(0,-60,-300);
 check(0x403,120,-180); /* Physical wheel must still scroll correctly. */
 check(0x403,120,-180); /* MyGUI's duplicated mouse injection is harmless. */
 check(0,180,-120);
 check(0x400,120,-120);
 check(0,0,-240);
 puts("PASS: 10 mouse/controller scroll transitions, no rollback; physical wheel preserved.");
}
