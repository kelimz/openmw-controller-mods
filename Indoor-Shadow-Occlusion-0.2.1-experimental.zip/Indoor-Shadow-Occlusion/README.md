# Indoor Shadow Occlusion 0.2.1 — experimental

AI-generated implementation developed with OpenAI Codex at the user's direction. Limited local validation; no independent audit. Source is included. GPL-3.0-only for the helper. Vendored OpenSceneGraph headers retain their own license.

This helper preserves indoor actor shadows while preventing the nearest actor shadow from projecting through intervening solid scene geometry. The original actor shadow pass also records raw actor depth. A second pass renders the first static surface after the actor along each light ray. Receivers beyond that surface are excluded from the shadow. Roofs in front of the actor are discarded from the second pass, so they do not suppress all interior shadows.

Version 0.2 also raycasts down to each actor's supporting surface, records its plane in the actor shadow map, and excludes receivers more than 24 game units below that plane. This handles open balconies where there is no intervening floor along the directional shadow ray. Sloped floor normals are used where suitable, and the support plane is refreshed five times per second. This applies to standard actor nodes in all interiors; there are no cell-name exceptions.

OpenMW's ShadowsBin normally strips per-actor uniforms while combining opaque geometry. The helper retains only the support-plane uniform after those optimisations, preserving native material/alpha-test decisions.

Tested only with Linux x86-64 OpenMW Flatpak 0.51.0 f4bec41444, OpenMW's OSG fork ABI 162 (commit e568aace1e62de021df9955c62429cbe55516fd3), float matrices/planes, two shadow maps, object shadows enabled outdoors, and NVIDIA OpenGL. Unsupported renderer changes may break this native helper.

## Toggle
Enable/disable `indoor_shadow_occlusion.omwscripts` in OpenMW Data Files, then restart OpenMW. Keep `enable indoor shadows = true` to use indoor shadows. The native library remains registered but passes through when this content file is disabled.

## Build
Run `./build.sh` with GCC/G++ installed. The local Flatpak supplies matching shared libraries; matching OSG and GL headers are included under vendor/include. No system game files are patched. The generated OSG Config uses float matrices/planes, matching the installed Flatpak.

## Limits
This is floor/wall occlusion for OpenMW's existing directional actor shadows; it does not implement shadows from candles or lamps. Static geometry is treated as opaque. As with a single-layer shadow map, overlapping actors on different floors can obscure a lower actor's shadow at the same light-space coordinate. Two additional passes for the two shadow maps, per-actor floor queries, and preserved shadow-state groups increase GPU/CPU work indoors. Receivers substantially below the supporting floor are intentionally excluded; very long shadows down staircases or irregular surfaces may be shortened. Lighting/shader mods, stereo, other OSG builds and other GPU drivers are untested. Tested with two maps only; the fix passes through for other map counts. Interior/exterior detection relies on OpenMW's native caster masks, so keep outdoor object shadows enabled.

## Remove
Remove only this library from the Flatpak LD_PRELOAD override, remove its content/data entries, then restart. Existing Controller Comfort and Quick Menu Names helpers are separate.

## Local validation for 0.2
Tested the user-provided quicksave in Vivec, St. Olms Waistworks at an open balcony. A diagnostic build marked 108,245 cross-floor shadow pixels for rejection and retained 321,374 valid shadow pixels; GPU readback confirmed both supporting heights (-128 and -384) reached the shadow pass without fallback values. A normal build removed the reported silhouettes while retaining the player shadow. No test save was written. Other interiors and long play sessions have not been exhaustively tested.

## Projection synchronization fix in 0.2.1
The blocker camera now copies the native camera projection after OpenMW finalizes its perspective shadow adjustment. Copying it during the caster callback used an earlier projection and could incorrectly remove nearby NPC shadows as the view moved. At the supplied St. Olms Waistworks save, the corrected floor shadow matches the native engine at four sampled points previously removed by 0.2.0. The floor-height exclusion remains unchanged.

## Installation — Linux Flatpak only
Close OpenMW and its launcher. Extract the complete Indoor-Shadow-Occlusion folder to a permanent directory, for example ~/.local/share/openmw-mods/. Add its DataFiles directory to OpenMW data directories and select indoor_shadow_occlusion.omwscripts.

Inspect existing overrides with `flatpak override --user --show org.openmw.OpenMW`. Add the absolute path to native/indoor_shadows.so to this app's LD_PRELOAD. Preserve all existing helpers in the colon-separated value; setting LD_PRELOAD replaces that entire value. Example for this helper alone:

`flatpak override --user --env=LD_PRELOAD=/absolute/path/to/Indoor-Shadow-Occlusion/native/indoor_shadows.so org.openmw.OpenMW`

Keep indoor shadows enabled, use two shadow maps, and enable outdoor object shadows. These conditions are required by the current implementation. Windows and macOS are unsupported. This is a native engine extension, not a portable Lua-only mod. Keep paths accessible inside Flatpak. Build with bash build.sh; the matching OSG/GL headers and their notices are in vendor/.

Restart after toggling the mod. To uninstall, remove only this helper from LD_PRELOAD, preserving other helpers, and remove its data/content entries. Back up configuration and saves before trying this experimental release.
