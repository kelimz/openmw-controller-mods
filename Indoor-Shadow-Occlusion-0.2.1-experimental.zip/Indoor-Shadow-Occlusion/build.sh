#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
app=${OPENMW_FLATPAK_FILES:-/var/lib/flatpak/app/org.openmw.OpenMW/current/active/files}
mkdir -p native
c++ -std=c++17 -shared -fPIC -O2 -Wall -Wextra -Wno-deprecated-copy -Ivendor/include source/indoor_shadows.cpp -o native/indoor_shadows.so -L"$app/lib" -Wl,--allow-shlib-undefined -l:libosg.so.3.6.5 -l:libosgUtil.so.3.6.5 -l:libosgShadow.so.3.6.5 -ldl
