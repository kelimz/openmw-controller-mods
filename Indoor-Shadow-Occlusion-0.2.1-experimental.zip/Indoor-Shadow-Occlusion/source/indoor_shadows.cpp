#include <osg/Camera>
#include <osg/Depth>
#include <osg/ClipControl>
#include <algorithm>
#include <osg/Shader>
#include <osg/Program>
#include <osg/Texture2D>
#include <osg/Uniform>
#include <osg/StateSet>
#include <osg/NodeCallback>
#include <osgShadow/ShadowedScene>
#include <osgShadow/ShadowSettings>
#include <osgUtil/CullVisitor>
#include <osgUtil/LineSegmentIntersector>
#include <osgUtil/IntersectionVisitor>
#include <osgUtil/RenderBin>
#include <osgUtil/StateGraph>
#include <osgUtil/RenderLeaf>
#include <chrono>
#include <dlfcn.h>
#include <map>
#include <vector>
#include <mutex>
#include <string>
#include <cstdio>

#include "mod_gate.h"
namespace {
constexpr unsigned Scene=1<<14, Actor=1<<3, Player=1<<4, Objects=(1<<10)|(1<<11);
thread_local osgShadow::ShadowedScene* currentScene=nullptr;
thread_local bool inside=false, extraPass=false;
std::recursive_mutex mutex;
bool enabled(){static bool b=mod_selected("indoor_shadow_occlusion.omwscripts");return b;}
void debug(const char*s){if(getenv("OPENMW_INDOOR_SHADOW_DEBUG"))fprintf(stderr,"[Indoor Shadow Occlusion] %s\n",s);}
template<class T>T next(const char*s){auto f=reinterpret_cast<T>(dlsym(RTLD_NEXT,s));if(!f){fprintf(stderr,"Missing OSG symbol %s\n",s);abort();}return f;}
const char* vert="#version 120\nvoid main(){gl_Position=ftransform();}\n";
const char* frag="#version 120\nuniform sampler2D actorDepth; uniform vec2 mapSize; void main(){float actor=texture2D(actorDepth,gl_FragCoord.xy/mapSize).r; if(gl_FragCoord.z<=actor+0.00001)discard;gl_FragColor=vec4(1.0);}\n";
struct StaticTraversal:osg::NodeCallback {
 osg::observer_ptr<osgShadow::ShadowedScene> scene;
 explicit StaticTraversal(osgShadow::ShadowedScene*s):scene(s){}
 void operator()(osg::Node*,osg::NodeVisitor*nv) override {if(scene.valid())scene->osg::Group::traverse(*nv);}
};
struct Maps {
 osg::ref_ptr<osg::Texture2D> actor,blocker,source;
 osg::ref_ptr<osg::Camera> camera;
};
std::map<osg::Camera*,Maps> cameras;
thread_local std::vector<osg::Camera*> pending;
std::map<osg::Texture*,osg::ref_ptr<osg::Texture2D>> blockers;
std::map<osg::Texture*,osg::Camera*> actorCameras;
struct ActorFloors : osg::NodeVisitor {
 osgShadow::ShadowedScene* scene;
 unsigned actors=0;
 explicit ActorFloors(osgShadow::ShadowedScene*s):NodeVisitor(TRAVERSE_ACTIVE_CHILDREN),scene(s){setTraversalMask(Scene|Actor|Player);}
 void apply(osg::Node&node) override {
  unsigned mask=node.getNodeMask();
  if((mask&(Actor|Player)) && !(mask&~(Actor|Player))){
   osg::Vec3d origin=osg::computeLocalToWorld(getNodePath()).getTrans();
   osg::Vec3 plane(0,0,origin.z()-8);
   osg::ref_ptr<osgUtil::LineSegmentIntersector> ray=new osgUtil::LineSegmentIntersector(origin+osg::Vec3d(0,0,48),origin-osg::Vec3d(0,0,8192));
   osgUtil::IntersectionVisitor iv(ray);iv.setTraversalMask(Scene|Objects);
   scene->osg::Group::traverse(iv);
   for(const auto&hit:ray->getIntersections()){
    auto point=hit.getWorldIntersectPoint();auto normal=hit.getWorldIntersectNormal();
    if(point.z()>origin.z()+32 || normal.z()<0.25)continue;
    float a=0,b=0;
    if(normal.z()>0.6){a=-normal.x()/normal.z();b=-normal.y()/normal.z();}
    plane=osg::Vec3(a,b,point.z()-a*point.x()-b*point.y());break;
   }
   auto*ss=node.getOrCreateStateSet();auto*u=ss->getUniform("indoorSupportPlane");
   if(u)u->set(plane);else ss->addUniform(new osg::Uniform("indoorSupportPlane",plane));
   if(getenv("OPENMW_INDOOR_SHADOW_DEBUG")){static unsigned count=0;if(count++<20)fprintf(stderr,"[Indoor Shadow Occlusion] Actor floor at %.1f %.1f %.1f plane %.3f %.3f %.1f\n",origin.x(),origin.y(),origin.z(),plane.x(),plane.y(),plane.z());}
   ++actors;return;
  }
  traverse(node);
 }
};
void updateActorFloors(osgShadow::ShadowedScene*scene){
 using Clock=std::chrono::steady_clock;
 static std::map<osgShadow::ShadowedScene*,Clock::time_point>last;
 auto now=Clock::now();if(now-last[scene]<std::chrono::milliseconds(200))return;last[scene]=now;
 ActorFloors visitor(scene);scene->osg::Group::traverse(visitor);
}

osg::Texture2D* texture(int w,int h,bool depth){
 auto*t=new osg::Texture2D;t->setTextureSize(w,h);
 t->setInternalFormat(depth?GL_DEPTH_COMPONENT32F:GL_RGBA32F);
 t->setSourceFormat(depth?GL_DEPTH_COMPONENT:GL_RGBA);t->setSourceType(GL_FLOAT);
 t->setFilter(osg::Texture::MIN_FILTER,osg::Texture::NEAREST);t->setFilter(osg::Texture::MAG_FILTER,osg::Texture::NEAREST);
 t->setWrap(osg::Texture::WRAP_S,osg::Texture::CLAMP_TO_EDGE);t->setWrap(osg::Texture::WRAP_T,osg::Texture::CLAMP_TO_EDGE);
 t->setShadowComparison(false);return t;
}
}
namespace osg {
void Shader::setShaderSource(const std::string&original){
 static auto real=next<void(*)(Shader*,const std::string&)>("_ZN3osg6Shader15setShaderSourceERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE");
 std::string s=original;
 if(enabled()){
  const std::string colour="gl_FragData[0].rgb = vec3(1.0);";
  auto pos=s.find(colour);
  if(pos!=std::string::npos&&s.find("useDiffuseMapForShadowAlpha")!=std::string::npos){
   auto main=s.find("void main()");s.insert(main,"uniform vec3 indoorSupportPlane;\n");
   auto end=s.rfind('}');s.insert(end,"gl_FragData[0] = vec4(gl_FragCoord.z, indoorSupportPlane);\n");
   debug("Patched actor depth and supporting floor output");}
  if(s.find("float unshadowedLightRatio(")!=std::string::npos){
   std::string uniforms="\nuniform bool indoorFloorOcclusion;\n";
   for(int i=0;i<8;i++){
    std::string n=std::to_string(i),old="shadowing = min(shadow2DProj(shadowTexture"+n+", shadowSpaceCoords"+n+").r, shadowing);";
    auto p=s.find(old);if(p==std::string::npos)continue;
    uniforms+="uniform sampler2D indoorBlocker"+n+";\nuniform sampler2D indoorActor"+n+";\nuniform mat4 indoorShadowToWorld"+n+";\n";
    std::string code=old+"\nif(indoorFloorOcclusion && shadowing < 1.0){float barrier=texture2D(indoorBlocker"+n+",shadowXYZ.xy).r;vec4 actor=texture2D(indoorActor"+n+",shadowXYZ.xy);vec4 world=indoorShadowToWorld"+n+"*shadowSpaceCoords"+n+";world.xyz/=world.w;float support=dot(actor.gba,vec3(world.xy,1.0));if(shadowXYZ.z > barrier+0.00015 || world.z < support-24.0)shadowing=1.0;}\n";
    s.replace(p,old.size(),code);
   }
   // GLSL directives must remain before declarations.
   auto f=s.find("float unshadowedLightRatio(");s.insert(f,uniforms);debug("Patched floor-aware shadow receiver");
  }
 }
  real(this,s);
}
void StateSet::setTextureAttribute(unsigned unit,StateAttribute*attribute,unsigned value){
 static auto real=next<void(*)(StateSet*,unsigned,StateAttribute*,unsigned)>("_ZN3osg8StateSet19setTextureAttributeEjPNS_14StateAttributeEj");
 real(this,unit,attribute,value);
 if(!enabled()||extraPass||!currentScene||unit<16)return;
 std::lock_guard<std::recursive_mutex> lock(mutex);
 auto*t=dynamic_cast<Texture*>(attribute);if(!t||!t->getShadowComparison())return;
 bool active=inside&&blockers.count(t);
 addUniform(new Uniform("indoorFloorOcclusion",active));
 if(!active)return;
 for(int index=0;index<8;index++){
  auto*u=getUniform("shadowTexture"+std::to_string(index));int bound=-1;
  if(u&&u->get(bound)&&bound==int(unit)){
   unsigned bunit=unit-8;real(this,bunit,blockers[t],value);
   addUniform(new Uniform(("indoorBlocker"+std::to_string(index)).c_str(),int(bunit)));
   auto*c=actorCameras[t];auto&m=cameras[c];unsigned aunit=unit-12;real(this,aunit,m.actor,value);
   addUniform(new Uniform(("indoorActor"+std::to_string(index)).c_str(),int(aunit)));
   osg::Matrix matrix=osg::Matrix::inverse(c->getViewMatrix()*c->getProjectionMatrix()*osg::Matrix::translate(1,1,1)*osg::Matrix::scale(.5,.5,.5));
   addUniform(new Uniform(("indoorShadowToWorld"+std::to_string(index)).c_str(),matrix));
  }
 }
}
}
namespace osg {
bool NodeCallback::run(Object*node,Object*visitor){
 static auto real=next<bool(*)(NodeCallback*,Object*,Object*)>("_ZN3osg12NodeCallback3runEPNS_6ObjectES2_");
 auto*n=node?node->asNode():nullptr;auto*nv=visitor?visitor->asNodeVisitor():nullptr;auto*c=n?n->asCamera():nullptr;
 if(enabled()&&c&&nv&&nv->getVisitorType()==osg::NodeVisitor::CULL_VISITOR&&c->getName()=="ShadowCamera"){
  auto*ss=c->getOrCreateStateSet();auto*u=ss->getUniform("indoorCameraFloorPass");
  if(u)u->set(inside&&!extraPass);else ss->addUniform(new osg::Uniform("indoorCameraFloorPass",inside&&!extraPass));
 }
 if(!enabled()||!c||!nv||!currentScene||!inside||extraPass||nv->getVisitorType()!=osg::NodeVisitor::CULL_VISITOR||c->getRenderOrder()!=Camera::PRE_RENDER)return real(this,node,visitor);
 auto a=c->getBufferAttachmentMap().find(Camera::DEPTH_BUFFER);
 auto*depth=a==c->getBufferAttachmentMap().end()?nullptr:dynamic_cast<Texture2D*>(a->second._texture.get());
 if(!depth||!depth->getShadowComparison())return real(this,node,visitor);
 std::lock_guard<std::recursive_mutex>lock(mutex);
 auto&m=cameras[c];
 if(m.source.get()!=depth || (m.actor.valid() && (m.actor->getTextureWidth()!=depth->getTextureWidth() || m.actor->getTextureHeight()!=depth->getTextureHeight()))){
  if(m.source.valid()){blockers.erase(m.source.get());actorCameras.erase(m.source.get());}
  m=Maps{};m.source=depth;
 }
 if(!m.camera){
  int w=depth->getTextureWidth(),h=depth->getTextureHeight();
  m.actor=texture(w,h,false);m.blocker=texture(w,h,true);
  c->attach(osg::Camera::COLOR_BUFFER0,m.actor);
  c->setClearColor(osg::Vec4(1,1,1,1));
  c->getOrCreateStateSet()->addUniform(new osg::Uniform("indoorSupportPlane",osg::Vec3(0,0,-100000000.0f)));
  m.camera=new osg::Camera;
  m.camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
  m.camera->setRenderOrder(osg::Camera::PRE_RENDER,c->getRenderOrderNum()+1);
  m.camera->setRenderTargetImplementation(osg::Camera::FRAME_BUFFER_OBJECT);
  m.camera->setClearMask(GL_DEPTH_BUFFER_BIT);m.camera->setClearDepth(1.0);
  m.camera->setViewport(0,0,w,h);m.camera->setComputeNearFarMode(osg::CullSettings::DO_NOT_COMPUTE_NEAR_FAR);
  m.camera->setCullMask(Scene|Objects);m.camera->setCullingActive(false);
  m.camera->attach(osg::Camera::DEPTH_BUFFER,m.blocker);
  m.camera->setCullCallback(new StaticTraversal(currentScene));
  auto*s=m.camera->getOrCreateStateSet();auto*p=new osg::Program;
  p->addShader(new osg::Shader(osg::Shader::VERTEX,vert));p->addShader(new osg::Shader(osg::Shader::FRAGMENT,frag));
  unsigned flags=osg::StateAttribute::ON|osg::StateAttribute::OVERRIDE;
  s->setAttributeAndModes(p,flags);s->setAttributeAndModes(new osg::Depth(osg::Depth::LESS,0,1,true),flags);
  s->setAttribute(new osg::ClipControl(osg::ClipControl::LOWER_LEFT,osg::ClipControl::NEGATIVE_ONE_TO_ONE),flags);
  s->setMode(GL_DEPTH_CLAMP,flags);
  s->setMode(GL_CULL_FACE,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);
  s->setMode(GL_BLEND,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);
  s->setTextureAttributeAndModes(1,m.actor,flags);
  s->addUniform(new osg::Uniform("actorDepth",1));s->addUniform(new osg::Uniform("mapSize",osg::Vec2(w,h)));
  blockers[depth]=m.blocker;actorCameras[depth]=c;debug("Created indoor static occlusion pass");
 }
 bool result=real(this,node,visitor);
 pending.push_back(c);return result;
}
}
namespace osgShadow {
void ShadowedScene::traverse(osg::NodeVisitor&nv){
 static auto real=next<void(*)(ShadowedScene*,osg::NodeVisitor&)>("_ZN9osgShadow13ShadowedScene8traverseERN3osg11NodeVisitorE");
 auto*prev=currentScene;bool prevInside=inside;
 if(enabled()&&nv.getVisitorType()==osg::NodeVisitor::CULL_VISITOR){
  currentScene=this;unsigned mask=getShadowSettings()->getCastsShadowTraversalMask();inside=(mask&(Actor|Player))&&!(mask&Objects)&&getShadowSettings()->getNumShadowMapsPerLight()==2;
 }
 if(inside&&!extraPass&&nv.getVisitorType()==osg::NodeVisitor::CULL_VISITOR)updateActorFloors(this);
 auto saved=std::move(pending);pending.clear();
 real(this,nv);
 if(inside&&!extraPass){
  auto mask=nv.getTraversalMask();nv.setTraversalMask(Scene|Objects);extraPass=true;
  auto queue=std::move(pending);pending.clear();
  // OpenMW adjusts perspective shadow projection after the caster cull.
  // Synchronize here, after the native shadow traversal has finalized it.
  for(auto*c:queue){
   auto*blocker=cameras[c].camera.get();
   blocker->setViewMatrix(c->getViewMatrix());
   blocker->setProjectionMatrix(c->getProjectionMatrix());
   blocker->accept(nv);
  }
  extraPass=false;nv.setTraversalMask(mask);
 }
 pending=std::move(saved);currentScene=prev;inside=prevInside;
}
}


namespace osgUtil {
void RenderBin::sort(){
 static auto real=next<void(*)(RenderBin*)>("_ZN7osgUtil9RenderBin4sortEv");
 if(!enabled()||_sorted||std::string(className())!="ShadowsBin"){real(this);return;}
 std::map<RenderLeaf*,osg::ref_ptr<osg::Uniform>> support;
 for(auto*graph:getStateGraphList()){
  osg::Uniform*plane=nullptr;bool indoor=false;
  for(auto*g=graph;g;g=g->_parent){
   auto*ss=g->getStateSet();if(!ss)continue;
   if(!plane)plane=const_cast<osg::Uniform*>(ss->getUniform("indoorSupportPlane"));
   if(auto*u=ss->getUniform("indoorCameraFloorPass"))u->get(indoor);
  }
  if(indoor&&plane)for(auto&leaf:graph->_leaves)support[leaf.get()]=plane;
 }
 real(this);
 if(support.empty())return;
 // OpenMW's ShadowsBin strips actor-specific uniforms while merging opaque
 // leaves. Restore only the supporting-plane uniform after its alpha/cull
 // optimisations, preserving all native visibility and alpha-test decisions.
 static std::map<osg::Uniform*,osg::ref_ptr<osg::StateSet>> states;
 StateGraphList list;
 for(auto*graph:getStateGraphList()){
  auto leaves=std::move(graph->_leaves);graph->_leaves.clear();
  std::map<StateGraph*,bool> added;
  for(auto&leaf:leaves){
   auto found=support.find(leaf.get());
   if(found==support.end()){graph->_leaves.push_back(leaf);continue;}
   auto&ss=states[found->second.get()];if(!ss){ss=new osg::StateSet;ss->addUniform(found->second);}
   auto*child=graph->find_or_insert(ss);child->_leaves.push_back(leaf);leaf->_parent=child;
   if(!added[child]){list.push_back(child);added[child]=true;}
  }
  if(!graph->_leaves.empty())list.push_back(graph);
 }
 getStateGraphList()=std::move(list);
}
}
