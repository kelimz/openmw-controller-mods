"""Regression expectations for the two actual Waistworks levels and slopes."""
def allowed(plane, point):
    a,b,c=plane;x,y,z=point
    return z >= a*x+b*y+c-24
assert not allowed((0,0,-128),(1200,-500,-384)) # open balcony: no wall required
assert allowed((0,0,-384),(1200,-500,-384))    # lower-floor actor still shadows there
assert allowed((0,0,-128),(1200,-500,-128))    # upper-floor actor shadows its own gallery
assert allowed((0,0,-128),(1200,-500,-144))    # small step tolerance
assert not allowed((0,0,-128),(1200,-500,-256))
assert allowed((.2,0,0),(100,0,20))           # sloping supporting floor
assert not allowed((.2,0,0),(100,0,-80))
print('Seven balcony, step and slope expectations passed')
