"""Light-space depth cases for the static-blocker pass and receiver."""
def blocker(actor, surfaces):
    return min([x for x in surfaces if x > actor + 0.00001] + [1.0])
def shadow(actor, surfaces, receiver):
    return actor < receiver and receiver <= blocker(actor, surfaces) + 0.00015
assert shadow(.2, [.1, .4], .4)       # NPC on upper floor keeps a shadow there
assert not shadow(.2, [.1, .4], .7)   # that NPC cannot shadow lower floor
assert shadow(.6, [.1, .4, .7], .7)   # lower NPC keeps shadow; roof ignored
assert shadow(.2, [], .7)            # no blocker: original actor shadow
assert not shadow(.8, [.4], .4)       # receiver in front of caster stays lit
print('Five floor/roof depth cases passed')
