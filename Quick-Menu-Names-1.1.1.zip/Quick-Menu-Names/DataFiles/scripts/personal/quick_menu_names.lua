-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (c) 2026 kelimz; predominantly AI-generated.
local core=require('openmw.core')
local ui=require('openmw.ui')
local util=require('openmw.util')
local I=require('openmw.interfaces')
local bridge
local function refresh()
    local parts={'__QKNAMES__'}
    local count=0
    for _,spell in pairs(core.magic.spells.records) do
        local id,name=spell.id,spell.name
        parts[#parts+1]=#id..':'..id..#name..':'..name
        count=count+1
    end
    if bridge then bridge:destroy() end
    bridge=ui.create{type=ui.TYPE.Text,layer='HUD',name='QuickNamesRegistry',props={
        visible=false,position=util.vector2(-10000,-10000),size=util.vector2(1,1),text=table.concat(parts)}}
    print('[Quick Menu Names] Spell names synchronized: '..count)
end
return {engineHandlers={onLoad=refresh,onInit=refresh},eventHandlers={UiModeChanged=function()
    if I.UI.getMode()==I.UI.MODE.QuickKeysMenu then refresh() end
end}}
