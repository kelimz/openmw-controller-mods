# Quick Menu Names 1.1

Enable or disable **Quick Menu Names.omwscripts** in OpenMW's Data Files list.
No separate program is needed. This adds live names beneath the standard ten
quick-menu slots and lets you use the menu to select your equipped item or magic.

Controller controls:
- D-pad: highlight a slot (left-stick pointer selection also works).
- A: use/equip/ready the highlighted slot and close the menu.
- X: open the original assignment screen to change that slot.
- B: cancel/close without activating anything.
- A on an empty slot opens assignment instead.

Weapons equip and ready, spells/enchanted items ready for casting, and potions
are consumed only when explicitly activated with A. The engine's existing
quick-key action handles activation; slot assignments are not rewritten.
It labels spells, equipment, potions and enchanted items; blank slots show
Unassigned and slot 0 shows Hand-to-hand.

All mod files are in this folder. The installed native bootstrap is inactive
when this content checkbox is off. Original Morrowind files are not modified.
Quick-key assignments and character saves are not changed by this mod.

The native item-name reader is guarded for the exact OpenMW 0.51.0 Flatpak build
9ae172cf58a1254ca8b63da9df7079575eeba6ab (MyGUI 3.4.4, Linux x86-64). Check
compatibility before using it with a different engine build; it disables that
reader rather than interpreting another engine's object layout.

Source is in source/. Build:
g++ -std=c++17 -shared -fPIC -O2 -Wall -Wextra -Werror -o native/quick_names.so source/quick_names.cpp -ldl


## AI-generated and experimental

The implementation, documentation and release packaging were generated with AI assistance through OpenAI Codex, at the author’s direction. Most code is AI-generated. Human-directed testing covers only the scenarios described here; this is not an independently audited or broadly validated release. Bugs, crashes and incompatibilities remain possible. Back up saves and configuration before trying it. No game assets or save files are distributed.

Copyright (c) 2026 kelimz. This project is licensed under GPL-3.0-only; see LICENSE. Distributed WITHOUT ANY WARRANTY. This is an unofficial project and is not endorsed by OpenMW, Bethesda, or Nexus Mods.

## Installation (Linux Flatpak only)

Tested with OpenMW 0.51.0 revision f4bec41444, MyGUI 3.4.4, Linux x86-64. Windows, macOS, other engine versions and other distributions have not been validated. These are native LD_PRELOAD extensions plus Lua scripts, not ordinary portable Lua-only mods. Missing native symbols can terminate startup.

1. Close OpenMW and its launcher. Extract this entire folder to a permanent location under your home directory, such as `~/.local/share/openmw-mods/`.
2. Back up `~/.var/app/org.openmw.OpenMW/config/openmw/openmw.cfg` and your existing Flatpak overrides.
3. Add the absolute path to this mod’s `DataFiles` directory to OpenMW’s data directories (`data="/absolute/path/to/Quick-Menu-Names/DataFiles"` in that configuration). Enable `Quick Menu Names.omwscripts` in the launcher’s Data Files tab.
4. Inspect the existing override with `flatpak override --user --show org.openmw.OpenMW`. Set LD_PRELOAD to the absolute path of `native/quick_names.so` using `flatpak override --user --env=LD_PRELOAD=/absolute/path/to/Quick-Menu-Names/native/quick_names.so org.openmw.OpenMW`. If LD_PRELOAD already contains other helpers, preserve them and append this path separated by a colon. Setting the variable replaces the whole value. When installing both mods, include both paths in one colon-separated value.
5. Launch normally. There is no separate toggle application. Disable `Quick Menu Names.omwscripts` in Data Files and restart OpenMW to disable the mod. To uninstall, remove this helper’s entry from LD_PRELOAD while preserving all other entries, remove its content/data entries, then remove its folder. If startup fails, remove its LD_PRELOAD entry first.

Paths must remain readable inside the Flatpak sandbox. Keep content filenames unchanged for existing saves. Disabling a content file can cause an OpenMW missing-content warning when loading a save that references it.
