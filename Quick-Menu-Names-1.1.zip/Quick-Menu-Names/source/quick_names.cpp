// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2026 kelimz; predominantly AI-generated.
#define _GNU_SOURCE 1
#include <dlfcn.h>
#include <cxxabi.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <string_view>
#include <typeinfo>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>
#include <cstdint>
#include "mod_gate.h"
namespace MyGUI {class Widget;}
struct Coord{int left,top,width,height;};struct Align{unsigned value;};
static void *root,*buttons[10]{},*labels[10]{};
static std::string slot_names[10],spell_ids[10];
static std::unordered_map<std::string,std::string> spells;
static bool in_caption;
static bool selector_active();
template<class T>static T sym(const char*n){auto p=reinterpret_cast<T>(dlsym(RTLD_NEXT,n));if(!p){std::fprintf(stderr,"[Quick Menu Names] Missing %s\n",n);std::abort();}return p;}
static bool enabled(){static int v=-1;if(v<0)v=mod_selected("Quick Menu Names.omwscripts");return v;}
static bool engine_matches(){
 static int result=-1;if(result>=0)return result;
 const unsigned char id[]={0x9a,0xe1,0x72,0xcf,0x58,0xa1,0x25,0x4c,0xa8,0xb6,0x3d,0xa9,0xdf,0x70,0x79,0x57,0x5e,0xeb,0xa6,0xab};
 std::ifstream f("/proc/self/exe",std::ios::binary);std::string b(65536,'\0');f.read(b.data(),b.size());b.resize(f.gcount());
 result=b.find(std::string(reinterpret_cast<const char*>(id),sizeof(id)))!=std::string::npos;
 if(!result)std::fputs("[Quick Menu Names] Engine build differs; item-name ABI reader disabled\n",stderr);
 return result;
}
static void property(void*w,std::string_view k,std::string_view v){static auto fn=sym<void(*)(void*,std::string_view,std::string_view)>("_ZN5MyGUI6Widget11setPropertyESt17basic_string_viewIcSt11char_traitsIcEES4_");fn(w,k,v);}
static void setcoord(void*w,const Coord&c){static auto fn=sym<void(*)(void*,int,int,int,int)>("_ZN5MyGUI6Widget8setCoordEiiii");fn(w,c.left,c.top,c.width,c.height);}
static int index_of(void*w){for(int i=0;i<10;i++)if(buttons[i]==w)return i;return -1;}
static void *as_widget(void*userdata){
 static auto source=sym<const std::type_info*>("_ZTIN5MyGUI8UserDataE");
 static auto target=sym<const std::type_info*>("_ZTIN5MyGUI6WidgetE");
 return abi::__dynamic_cast(userdata,reinterpret_cast<const abi::__class_type_info*>(source),reinterpret_cast<const abi::__class_type_info*>(target),-1);
}
static void refresh(int i){
 if(!labels[i])return;
 if(!spell_ids[i].empty()){
  auto p=spells.find(spell_ids[i]);
  if(p!=spells.end())slot_names[i]=p->second;
 }
 std::string text=std::to_string(i==9?0:i+1)+"  "+(i==9?"Hand-to-hand":slot_names[i].empty()?"Unassigned":slot_names[i]);
 property(labels[i],"Caption",text);
}
static void refresh_all(){for(int i=0;i<10;i++)refresh(i);}
using Widgets=std::vector<MyGUI::Widget*>;
Widgets load(void*,std::string_view,std::string_view,MyGUI::Widget*) __asm__("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
Widgets load(void*self,std::string_view file,std::string_view prefix,MyGUI::Widget*parent){
 static auto original=sym<Widgets(*)(void*,std::string_view,std::string_view,MyGUI::Widget*)>("_ZN5MyGUI13LayoutManager10loadLayoutESt17basic_string_viewIcSt11char_traitsIcEES4_PNS_6WidgetE");
 auto widgets=original(self,file,prefix,parent);
 if(enabled() && file.find("openmw_quickkeys_menu.layout")!=std::string_view::npos && !widgets.empty()){
  root=widgets[0];
  static auto find=sym<void*(*)(void*,std::string_view)>("_ZN5MyGUI6Widget10findWidgetESt17basic_string_viewIcSt11char_traitsIcEE");
  static auto getparent=sym<void*(*)(void*)>("_ZNK5MyGUI6Widget9getParentEv");
  static auto create=sym<void*(*)(void*,std::string_view,std::string_view,const Coord&,Align,std::string_view)>("_ZN5MyGUI6Widget13createWidgetTESt17basic_string_viewIcSt11char_traitsIcEES4_RKNS_5types6TCoordIiEENS_5AlignES4_");
  setcoord(root,{0,0,940,342});
  for(int i=0;i<10;i++){
   buttons[i]=find(root,std::string(prefix)+"QuickKey"+std::to_string(i+1));
   if(!buttons[i])continue;
   auto container=getparent(buttons[i]);
   setcoord(container,{20,62,900,216});
   int x=(i%5)*180,y=(i/5)*108;
   setcoord(buttons[i],{x+60,y,60,60});
   labels[i]=create(container,"EditBox","SandText",{x,y+64,176,40},Align{0},std::string(prefix)+"QuickName"+std::to_string(i));
   property(labels[i],"Align","Left Top");
   property(labels[i],"NeedMouse","false");property(labels[i],"NeedKey","false");
   property(labels[i],"TextAlign","Center");property(labels[i],"MultiLine","true");property(labels[i],"WordWrap","true");property(labels[i],"Static","true");
  }
  // Explicit slot anchors prevent MyGUI from centering labels during resize.
  for(int i=0;i<10;i++)if(labels[i])setcoord(labels[i],{(i%5)*180,(i/5)*108+64,176,40});
  static auto child=sym<void*(*)(void*,size_t)>("_ZNK5MyGUI6Widget10getChildAtEm");
  if(auto title=child(root,0)){setcoord(title,{16,7,908,18});property(title,"Caption","Quick Menu");}
  auto instruction=find(root,std::string(prefix)+"InstructionLabel");
  if(instruction){setcoord(instruction,{23,28,894,24});property(instruction,"Caption","A: Use selected slot     X: Assign/change slot     B: Cancel");}
  refresh_all();std::fputs("[Quick Menu Names] Ten live labels added\n",stderr);
 }
 return widgets;
}
// These prefixes match OpenMW 0.51.0 build 9ae172cf... and are used only after
// checking that exact build ID. They expose the existing virtual getName API;
// no game objects or inventory state are modified.
struct PtrView;
struct ClassNameAPI{
 virtual void copy_to_cell();virtual ~ClassNameAPI();
 virtual void render();virtual void insert();virtual void physics();
 virtual std::string_view name(const PtrView&)const=0;
};
struct LivePrefix{void*vtable;const ClassNameAPI*cls;};
struct PtrView{LivePrefix*ref;void*cell;void*container;};
struct HolderPrefix{void*vtable;PtrView held;};
void data(void*,void*) __asm__("_ZN5MyGUI8UserData11setUserDataENS_3AnyE");
void data(void*self,void*any){
 static auto original=sym<void(*)(void*,void*)>("_ZN5MyGUI8UserData11setUserDataENS_3AnyE");
 if(enabled() && root && engine_matches()){
  int i=index_of(as_widget(self));
  if(i>=0){
   static auto type=sym<const std::type_info&(*)(void*)>("_ZNK5MyGUI3Any7getTypeEv");
   if(std::string_view(type(any).name())=="N7MWWorld3PtrE"){
    auto holder=*reinterpret_cast<HolderPrefix**>(any);
    if(holder && holder->held.ref && holder->held.ref->cls){
     auto name=holder->held.ref->cls->name(holder->held);
     slot_names[i]=std::string(name);spell_ids[i].clear();refresh(i);
     std::fprintf(stderr,"[Quick Menu Names] Item slot %d named\n",i+1);
    }
   }
  }
 }
 original(self,any);
}
void user_string(void*,std::string_view,std::string_view) __asm__("_ZN5MyGUI8UserData13setUserStringESt17basic_string_viewIcSt11char_traitsIcEES4_");
void user_string(void*self,std::string_view key,std::string_view value){
 static auto original=sym<void(*)(void*,std::string_view,std::string_view)>("_ZN5MyGUI8UserData13setUserStringESt17basic_string_viewIcSt11char_traitsIcEES4_");
 original(self,key,value);
 if(enabled() && root && key=="Spell"){
  int i=index_of(as_widget(self));if(i>=0){if(engine_matches() && value.size()==16 && static_cast<unsigned char>(value[8])==2){
      const std::string *id=nullptr;std::memcpy(&id,value.data(),sizeof(id));
      if(id){spell_ids[i]=*id;std::transform(spell_ids[i].begin(),spell_ids[i].end(),spell_ids[i].begin(),[](unsigned char c){return std::tolower(c);});}
     }else if(engine_matches() && value.size()==16 && static_cast<unsigned char>(value[8])==4){
      unsigned long long number=0;std::memcpy(&number,value.data(),8);char id[64];std::snprintf(id,sizeof(id),"generated:0x%llx",number);spell_ids[i]=id;
     }else spell_ids[i]=std::string(value);
     slot_names[i].clear();refresh(i);}
 }
}
void clear(void*) __asm__("_ZN5MyGUI8UserData16clearUserStringsEv");
void clear(void*self){
 static auto original=sym<void(*)(void*)>("_ZN5MyGUI8UserData16clearUserStringsEv");original(self);
 if(enabled() && root){int i=index_of(as_widget(self));if(i>=0){slot_names[i].clear();spell_ids[i].clear();refresh(i);}}
}
static bool parse_registry(std::string_view text){
 constexpr std::string_view prefix="__QKNAMES__";
 if(text.substr(0,prefix.size())!=prefix)return false;
 size_t pos=prefix.size();
 auto part=[&](std::string&out){size_t colon=text.find(':',pos);if(colon==text.npos)return false;size_t len=0;for(size_t n=pos;n<colon;n++){if(text[n]<'0'||text[n]>'9')return false;len=len*10+text[n]-'0';if(len>1000000)return false;}pos=colon+1;if(len>text.size()-pos)return false;out=std::string(text.substr(pos,len));pos+=len;return true;};
 while(pos<text.size()){std::string id,name;if(!part(id)||!part(name))break;std::transform(id.begin(),id.end(),id.begin(),[](unsigned char c){return std::tolower(c);});spells[id]=name;}
 std::fprintf(stderr,"[Quick Menu Names] Registry received: %zu spell names\n",spells.size());refresh_all();return true;
}
void caption(void*,const void*) __asm__("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
void caption(void*self,const void*text){
 static auto original=sym<void(*)(void*,const void*)>("_ZN5MyGUI7TextBox10setCaptionERKNS_7UStringE");
 if(enabled() && !in_caption){
  static auto utf=sym<const char*(*)(const void*)>("_ZNK5MyGUI7UString12asUTF8_c_strEv");
  const char*s=utf(text);
  if(selector_active()) {
   static auto getname=sym<const std::string&(*)(void*)>("_ZNK5MyGUI6Widget7getNameB5cxx11Ev");
   auto name=getname(self);
   const char *replacement=name.find("BtnAText")!=std::string::npos?"Use":name.find("BtnBText")!=std::string::npos?"Cancel":nullptr;
   if(replacement && std::strcmp(s,replacement)){in_caption=true;property(self,"Caption",replacement);in_caption=false;return;}
  }
  if(s && !std::strncmp(s,"__QKNAMES__",11)){in_caption=true;bool handled=parse_registry(s);in_caption=false;if(handled)return;}
 }
 original(self,text);
}

void edit_caption(void*,const void*) __asm__("_ZN5MyGUI8EditText10setCaptionERKNS_7UStringE");
void edit_caption(void*self,const void*text){
 static auto original=sym<void(*)(void*,const void*)>("_ZN5MyGUI8EditText10setCaptionERKNS_7UStringE");
 if(enabled() && !in_caption){
  static auto utf=sym<const char*(*)(const void*)>("_ZNK5MyGUI7UString12asUTF8_c_strEv");
  const char*s=utf(text);
  if(s && !std::strncmp(s,"__QKNAMES__",11)){in_caption=true;bool handled=parse_registry(s);in_caption=false;if(handled)return;}
 }
 original(self,text);
}
// Use the engine's existing hotkey activation after closing the menu. This
// preserves native equip/cast/potion rules and never edits quick-key assignments.
static int controller_focus=0,queued_slot=-1,queue_step=0;
static int32_t controller_instance;
static bool selector_was_visible,cursor_navigation;
static std::vector<unsigned char> assignment_buttons;
static size_t assignment_index;
static bool assignment_release;
static bool selector_active(){
 if(!enabled() || !root)return false;
 static auto visible=sym<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 static auto input=sym<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
 static auto modal=sym<bool(*)(void*)>("_ZNK5MyGUI12InputManager10isModalAnyEv");
 auto manager=input();return visible(root) && manager && !modal(manager);
}
static int hovered_slot(){
 static auto input=sym<void*(*)()>("_ZN5MyGUI12InputManager14getInstancePtrEv");
 static auto focus=sym<void*(*)(void*)>("_ZNK5MyGUI12InputManager19getMouseFocusWidgetEv");
 static auto parent=sym<void*(*)(void*)>("_ZNK5MyGUI6Widget9getParentEv");
 auto manager=input();if(!manager)return -1;
 for(void*w=focus(manager);w;w=parent(w)){int i=index_of(w);if(i>=0)return i;}
 return -1;
}
static int slot_scancode(int slot){
 int fallback=slot==9?39:30+slot;
 const char*xdg=std::getenv("XDG_CONFIG_HOME");if(!xdg)return fallback;
 std::ifstream f(std::string(xdg)+"/openmw/input_v3.xml");std::string text{std::istreambuf_iterator<char>(f),{}};
 auto start=text.find("<Control name=\""+std::to_string(31+slot)+"\"");if(start==text.npos)return fallback;
 auto end=text.find("</Control>",start),key=text.find("<KeyBinder key=\"",start);
 if(key==text.npos || key>end)return fallback;
 int code=std::atoi(text.c_str()+key+16);return code>0?code:fallback;
}
static void close_event(void*out,bool down){
 auto b=static_cast<unsigned char*>(out);std::memset(b,0,56);
 uint32_t type=down?0x651:0x652;std::memcpy(b,&type,4);std::memcpy(b+8,&controller_instance,4);b[12]=1;b[13]=down?1:0;
}
static void key_event(void*out,int slot,bool down){
 auto b=static_cast<unsigned char*>(out);std::memset(b,0,56);
 uint32_t type=down?0x300:0x301;std::memcpy(b,&type,4);b[12]=down?1:0;
 int scan=slot_scancode(slot);static auto code=sym<int(*)(int)>("SDL_GetKeyFromScancode");int key=code(scan);
 std::memcpy(b+16,&scan,4);std::memcpy(b+20,&key,4);
}
static int assignment_event(void*out){
 if(assignment_index>=assignment_buttons.size())return 0;
 close_event(out,!assignment_release);
 static_cast<unsigned char*>(out)[12]=assignment_buttons[assignment_index];
 if(assignment_release)++assignment_index;
 assignment_release=!assignment_release;
 return 1;
}
static void begin_assignment(int target){
 assignment_buttons={11,12}; // Hide pointer, then restore the same D-pad slot.
 int from=controller_focus;
 if(from/5!=target/5){assignment_buttons.push_back(11);from=(from+5)%10;}
 for(int n=0;n<(target%5-from%5+5)%5;n++)assignment_buttons.push_back(14);
 assignment_buttons.push_back(0); // Native A opens the normal assign dialog.
 assignment_index=0;assignment_release=false;controller_focus=target;cursor_navigation=false;
}
extern "C" int SDL_PollEvent(void*out){
 static auto original=sym<int(*)(void*)>("SDL_PollEvent");
 if(out && assignment_event(out))return 1;
 if(out && queued_slot>=0){
  if(queue_step==0)close_event(out,false);
  else key_event(out,queued_slot,queue_step==1);
  if(++queue_step>=3){queued_slot=-1;queue_step=0;}
  return 1;
 }
 int result=original(out);
 if(!enabled() || !root)return result;
 bool active=selector_active();
 static auto visible=sym<bool(*)(void*)>("_ZNK5MyGUI6Widget10getVisibleEv");
 bool root_visible=root && visible(root);
 if(root_visible && !selector_was_visible){controller_focus=0;cursor_navigation=false;}
 selector_was_visible=root_visible;
 if(!result || !out)return result;
 auto b=static_cast<unsigned char*>(out);uint32_t type;std::memcpy(&type,b,4);
 if(!active)return result;
 if(type==0x400)cursor_navigation=true;
 if(type==0x650 && (b[12]==0 || b[12]==1)){int16_t value;std::memcpy(&value,b+16,2);if(value>6000||value<-6000)cursor_navigation=true;}
 if(type!=0x651)return result;
 std::memcpy(&controller_instance,b+8,4);unsigned button=b[12];
 if(button>=11 && button<=14){
  cursor_navigation=false;
  if(button==11||button==12)controller_focus=(controller_focus+5)%10;
  else if(button==13)controller_focus=controller_focus%5==0?controller_focus+4:controller_focus-1;
  else controller_focus=controller_focus%5==4?controller_focus-4:controller_focus+1;
 }else if(button==2){
  int target=controller_focus;
  if(cursor_navigation){int hover=hovered_slot();if(hover>=0)target=hover;}
  begin_assignment(target);return assignment_event(out);
 }else if(button==0){
  int slot=controller_focus;
  if(cursor_navigation){int hover=hovered_slot();if(hover>=0)slot=hover;}
  if(slot!=9 && slot_names[slot].empty() && spell_ids[slot].empty()){begin_assignment(slot);return assignment_event(out);}
  queued_slot=slot;queue_step=0;close_event(out,true);
  std::fprintf(stderr,"[Quick Menu Names] Use slot %d\n",slot==9?0:slot+1);
 }
 return result;
}
